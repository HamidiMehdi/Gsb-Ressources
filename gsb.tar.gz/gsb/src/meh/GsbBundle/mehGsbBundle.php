<?php

namespace meh\GsbBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class mehGsbBundle extends Bundle
{
}
