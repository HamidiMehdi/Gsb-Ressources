<?php

/* mehGsbBundle:Visiteur:VueSaisirFicheFrais.html.twig */
class __TwigTemplate_354de0d88e0727b3458bd9981374df93dd59566fc3c95fd4b6ac58c6b18e9e78 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehGsbBundle::base_accueil.html.twig", "mehGsbBundle:Visiteur:VueSaisirFicheFrais.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'saisie_fiche_de_frais' => array($this, 'block_saisie_fiche_de_frais'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23ff03e933b2c037030c8b132451a8900ed566bcf43cc8841c510beb682c07d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23ff03e933b2c037030c8b132451a8900ed566bcf43cc8841c510beb682c07d1->enter($__internal_23ff03e933b2c037030c8b132451a8900ed566bcf43cc8841c510beb682c07d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Visiteur:VueSaisirFicheFrais.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_23ff03e933b2c037030c8b132451a8900ed566bcf43cc8841c510beb682c07d1->leave($__internal_23ff03e933b2c037030c8b132451a8900ed566bcf43cc8841c510beb682c07d1_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_1eba23fe0410f10f933b14763939fd9754a68629f4daed3299d19040d6266fcf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1eba23fe0410f10f933b14763939fd9754a68629f4daed3299d19040d6266fcf->enter($__internal_1eba23fe0410f10f933b14763939fd9754a68629f4daed3299d19040d6266fcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Saisir fiche de frais ";
        
        $__internal_1eba23fe0410f10f933b14763939fd9754a68629f4daed3299d19040d6266fcf->leave($__internal_1eba23fe0410f10f933b14763939fd9754a68629f4daed3299d19040d6266fcf_prof);

    }

    // line 3
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_32a4ccc27728c713c790d13f689a479112377f7a4e281c13c2b3916a1f5a340d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32a4ccc27728c713c790d13f689a479112377f7a4e281c13c2b3916a1f5a340d->enter($__internal_32a4ccc27728c713c790d13f689a479112377f7a4e281c13c2b3916a1f5a340d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Saisir fiche de frais";
        
        $__internal_32a4ccc27728c713c790d13f689a479112377f7a4e281c13c2b3916a1f5a340d->leave($__internal_32a4ccc27728c713c790d13f689a479112377f7a4e281c13c2b3916a1f5a340d_prof);

    }

    // line 4
    public function block_saisie_fiche_de_frais($context, array $blocks = array())
    {
        $__internal_b6c624c16456d1a167901efd859fda7230b12b13fb7c4a8cad3609154d3e67d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6c624c16456d1a167901efd859fda7230b12b13fb7c4a8cad3609154d3e67d4->enter($__internal_b6c624c16456d1a167901efd859fda7230b12b13fb7c4a8cad3609154d3e67d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "saisie_fiche_de_frais"));

        echo "active";
        
        $__internal_b6c624c16456d1a167901efd859fda7230b12b13fb7c4a8cad3609154d3e67d4->leave($__internal_b6c624c16456d1a167901efd859fda7230b12b13fb7c4a8cad3609154d3e67d4_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_3db41b23352e6f8cd7ef22245084b98d7cbdb3507c4be9420310fdc8c85040fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3db41b23352e6f8cd7ef22245084b98d7cbdb3507c4be9420310fdc8c85040fb->enter($__internal_3db41b23352e6f8cd7ef22245084b98d7cbdb3507c4be9420310fdc8c85040fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "       
    <div class='col-lg-4'></div>
    <div>
        <h1>";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["moisEtAnnee"]) ? $context["moisEtAnnee"] : $this->getContext($context, "moisEtAnnee")), "html", null, true);
        echo "</h1>
    </div>
    <div class='col-lg-4'></div>
    <p>Derniére modification : ";
        // line 12
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["derniereModif"]) ? $context["derniereModif"] : $this->getContext($context, "derniereModif")), "d/m/Y"), "html", null, true);
        echo "</p>
    
    
    ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), 'form_start');
        echo "
    <div><h3> Frais Forfait :</h3></div><br>
    <div class=\"col-lg-2\">";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "repasMidi", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "repasMidi", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "nuitee", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "nuitee", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "etape", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "etape", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "km", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "km", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-4\"><br>";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "valider", array()), 'widget');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "annuler", array()), 'widget');
        echo "</div>
    ";
        // line 22
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), 'form_end');
        echo "   
    
    
    <br>  
    <div class='col-lg-11'> <hr> </div>
    <br><br><br><br>
        
    
     ";
        // line 30
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), 'form_start');
        echo "
    <div><h3> Hors Forfait :</h3></div><br>
    <div class=\"col-lg-2\">";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "jour", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "jour", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "mois", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "mois", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "libelle", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "libelle", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "montant", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "montant", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-4\"><br>";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), "ajouter", array()), 'widget');
        echo "</div>
    ";
        // line 37
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formHorsForfait"]) ? $context["formHorsForfait"] : $this->getContext($context, "formHorsForfait")), 'form_end');
        echo "<br><br><br>
   
    <table width=100% class='table-hover' >
    ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesHorsForfait"]) ? $context["lesHorsForfait"] : $this->getContext($context, "lesHorsForfait")));
        foreach ($context['_seq'] as $context["_key"] => $context["unHorsForfait"]) {
            // line 41
            echo "        <tr>
            <td> ";
            // line 42
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unHorsForfait"], "datefrais", array()), "d/m/Y"), "html", null, true);
            echo " </td>
            <td> ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "libelle", array()), "html", null, true);
            echo " </td>
            <td> ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "montant", array()), "html", null, true);
            echo " </td>
            <td><a href=\"#\" onCLick=\"deleteHorsForfait(";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()), "html", null, true);
            echo ",'";
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "libelle", array()), "html", null, true);
            echo "', '";
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "montant", array()), "html", null, true);
            echo "')\"><button class='btn btn-danger'>Supprimer</button></a></td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unHorsForfait'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "    
    </table>
    
    <br>  
    <div class='col-lg-11'> <hr> </div>
    <br><br><br><br>
    
    
    ";
        // line 55
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), 'form_start');
        echo "
    <div><h3> Hors Classification :</h3></div><br>
    <div class=\"col-lg-2\">";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "justificatif", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "justificatif", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 58
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "montant", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "montant", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-4\"><br>";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "ajouter", array()), 'widget');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "annuler", array()), 'widget');
        echo "</div>
    ";
        // line 60
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), 'form_end');
        echo "  
    
    <br><br><br>
    <br><br><br>
    <br><br><br>
    <br><br><br>
        

";
        
        $__internal_3db41b23352e6f8cd7ef22245084b98d7cbdb3507c4be9420310fdc8c85040fb->leave($__internal_3db41b23352e6f8cd7ef22245084b98d7cbdb3507c4be9420310fdc8c85040fb_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Visiteur:VueSaisirFicheFrais.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  236 => 60,  230 => 59,  225 => 58,  220 => 57,  215 => 55,  205 => 47,  192 => 45,  188 => 44,  184 => 43,  180 => 42,  177 => 41,  173 => 40,  167 => 37,  163 => 36,  158 => 35,  153 => 34,  148 => 33,  143 => 32,  138 => 30,  127 => 22,  121 => 21,  116 => 20,  111 => 19,  106 => 18,  101 => 17,  96 => 15,  90 => 12,  84 => 9,  79 => 6,  73 => 5,  61 => 4,  49 => 3,  37 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehGsbBundle::base_accueil.html.twig' %}
{% block title %}Saisir fiche de frais {% endblock %}
{% block titrePage %}Saisir fiche de frais{% endblock %}
{% block saisie_fiche_de_frais %}active{% endblock %}
{% block contenu %}
       
    <div class='col-lg-4'></div>
    <div>
        <h1>{{ moisEtAnnee }}</h1>
    </div>
    <div class='col-lg-4'></div>
    <p>Derniére modification : {{ derniereModif|date('d/m/Y') }}</p>
    
    
    {{ form_start(formFraisForfait) }}
    <div><h3> Frais Forfait :</h3></div><br>
    <div class=\"col-lg-2\">{{ form_label(formFraisForfait.repasMidi) }}{{ form_widget(formFraisForfait.repasMidi) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formFraisForfait.nuitee) }}{{ form_widget(formFraisForfait.nuitee) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formFraisForfait.etape) }}{{ form_widget(formFraisForfait.etape) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formFraisForfait.km) }}{{ form_widget(formFraisForfait.km) }}</div>
    <div class=\"col-lg-4\"><br>{{ form_widget(formFraisForfait.valider) }} {{ form_widget(formFraisForfait.annuler) }}</div>
    {{ form_end(formFraisForfait) }}   
    
    
    <br>  
    <div class='col-lg-11'> <hr> </div>
    <br><br><br><br>
        
    
     {{ form_start(formHorsForfait) }}
    <div><h3> Hors Forfait :</h3></div><br>
    <div class=\"col-lg-2\">{{ form_label(formHorsForfait.jour) }}{{ form_widget(formHorsForfait.jour) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formHorsForfait.mois) }}{{ form_widget(formHorsForfait.mois) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formHorsForfait.libelle) }}{{ form_widget(formHorsForfait.libelle) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formHorsForfait.montant) }}{{ form_widget(formHorsForfait.montant) }}</div>
    <div class=\"col-lg-4\"><br>{{ form_widget(formHorsForfait.ajouter) }}</div>
    {{ form_end(formHorsForfait) }}<br><br><br>
   
    <table width=100% class='table-hover' >
    {% for unHorsForfait in lesHorsForfait%}
        <tr>
            <td> {{unHorsForfait.datefrais|date('d/m/Y') }} </td>
            <td> {{unHorsForfait.libelle}} </td>
            <td> {{unHorsForfait.montant}} </td>
            <td><a href=\"#\" onCLick=\"deleteHorsForfait({{unHorsForfait.idlignefraishorsforfait}},'{{unHorsForfait.libelle}}', '{{unHorsForfait.montant}}')\"><button class='btn btn-danger'>Supprimer</button></a></td>
        </tr>
    {% endfor %}    
    </table>
    
    <br>  
    <div class='col-lg-11'> <hr> </div>
    <br><br><br><br>
    
    
    {{ form_start(formHorsClassification) }}
    <div><h3> Hors Classification :</h3></div><br>
    <div class=\"col-lg-2\">{{ form_label(formHorsClassification.justificatif) }}{{ form_widget(formHorsClassification.justificatif) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formHorsClassification.montant) }}{{ form_widget(formHorsClassification.montant) }}</div>
    <div class=\"col-lg-4\"><br>{{ form_widget(formHorsClassification.ajouter) }} {{ form_widget(formHorsClassification.annuler) }}</div>
    {{ form_end(formHorsClassification) }}  
    
    <br><br><br>
    <br><br><br>
    <br><br><br>
    <br><br><br>
        

{% endblock %}", "mehGsbBundle:Visiteur:VueSaisirFicheFrais.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Visiteur/VueSaisirFicheFrais.html.twig");
    }
}
