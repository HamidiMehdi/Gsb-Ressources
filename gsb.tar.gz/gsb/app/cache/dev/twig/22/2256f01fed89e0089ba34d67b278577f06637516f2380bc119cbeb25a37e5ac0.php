<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_e12eebac9796ed45251ffe1634796aec5454299e34919c4da6cfc35beebb0853 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73fe1a1b61364126b1f3dfab40baa7f5dd58541e71ed0998498e5f1f410218bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73fe1a1b61364126b1f3dfab40baa7f5dd58541e71ed0998498e5f1f410218bc->enter($__internal_73fe1a1b61364126b1f3dfab40baa7f5dd58541e71ed0998498e5f1f410218bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_73fe1a1b61364126b1f3dfab40baa7f5dd58541e71ed0998498e5f1f410218bc->leave($__internal_73fe1a1b61364126b1f3dfab40baa7f5dd58541e71ed0998498e5f1f410218bc_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_9ebd3b2c59e056a6f418494bd4a1afb6123b8495aba039d4ce23222db9cd4463 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ebd3b2c59e056a6f418494bd4a1afb6123b8495aba039d4ce23222db9cd4463->enter($__internal_9ebd3b2c59e056a6f418494bd4a1afb6123b8495aba039d4ce23222db9cd4463_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_9ebd3b2c59e056a6f418494bd4a1afb6123b8495aba039d4ce23222db9cd4463->leave($__internal_9ebd3b2c59e056a6f418494bd4a1afb6123b8495aba039d4ce23222db9cd4463_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/var/www/gsb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
