<?php

/* mehGsbBundle:Comptable:VueValiderFrais.html.twig */
class __TwigTemplate_6223bb214aefe3353505a49d39a57822d7bcdfec11be7cffb8274a22dd982eaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehGsbBundle::base_accueil.html.twig", "mehGsbBundle:Comptable:VueValiderFrais.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'validation_des_frais' => array($this, 'block_validation_des_frais'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_faf51168736a8f4ba7d032dbca5a34c07a21c2706c8b990b3221fc84f2d33d4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_faf51168736a8f4ba7d032dbca5a34c07a21c2706c8b990b3221fc84f2d33d4e->enter($__internal_faf51168736a8f4ba7d032dbca5a34c07a21c2706c8b990b3221fc84f2d33d4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Comptable:VueValiderFrais.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_faf51168736a8f4ba7d032dbca5a34c07a21c2706c8b990b3221fc84f2d33d4e->leave($__internal_faf51168736a8f4ba7d032dbca5a34c07a21c2706c8b990b3221fc84f2d33d4e_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_c4f03078da846b392ca358fd3b551743ab7a1822b661c677c81dbaf12eaacd8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4f03078da846b392ca358fd3b551743ab7a1822b661c677c81dbaf12eaacd8d->enter($__internal_c4f03078da846b392ca358fd3b551743ab7a1822b661c677c81dbaf12eaacd8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Valider frais";
        
        $__internal_c4f03078da846b392ca358fd3b551743ab7a1822b661c677c81dbaf12eaacd8d->leave($__internal_c4f03078da846b392ca358fd3b551743ab7a1822b661c677c81dbaf12eaacd8d_prof);

    }

    // line 3
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_873350359d7401df75aa30f3c56f9f0703ec85ed5afc81da44001ac874359f2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_873350359d7401df75aa30f3c56f9f0703ec85ed5afc81da44001ac874359f2f->enter($__internal_873350359d7401df75aa30f3c56f9f0703ec85ed5afc81da44001ac874359f2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Choisir un visiteur et un mois";
        
        $__internal_873350359d7401df75aa30f3c56f9f0703ec85ed5afc81da44001ac874359f2f->leave($__internal_873350359d7401df75aa30f3c56f9f0703ec85ed5afc81da44001ac874359f2f_prof);

    }

    // line 4
    public function block_validation_des_frais($context, array $blocks = array())
    {
        $__internal_c4bea23005b2589b708722d6e51b98b9ba299450d6dcd3f6f43cb4ddd32db5c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4bea23005b2589b708722d6e51b98b9ba299450d6dcd3f6f43cb4ddd32db5c0->enter($__internal_c4bea23005b2589b708722d6e51b98b9ba299450d6dcd3f6f43cb4ddd32db5c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "validation_des_frais"));

        echo "active";
        
        $__internal_c4bea23005b2589b708722d6e51b98b9ba299450d6dcd3f6f43cb4ddd32db5c0->leave($__internal_c4bea23005b2589b708722d6e51b98b9ba299450d6dcd3f6f43cb4ddd32db5c0_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_c91d0fe5b48d38162d32d4b7952127e619483bfee3588216bac32416d1cc842c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c91d0fe5b48d38162d32d4b7952127e619483bfee3588216bac32416d1cc842c->enter($__internal_c91d0fe5b48d38162d32d4b7952127e619483bfee3588216bac32416d1cc842c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "    
    ";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    <div class=\"col-lg-3\">";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "visiteurs", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mois", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "voir", array()), 'widget');
        echo "</div>
    ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo " 
    
    ";
        // line 13
        if ( !twig_test_empty((isset($context["aucuneFiche"]) ? $context["aucuneFiche"] : $this->getContext($context, "aucuneFiche")))) {
            // line 14
            echo "        <div class=\"col-lg-6\"><br><h5>";
            echo twig_escape_filter($this->env, (isset($context["aucuneFiche"]) ? $context["aucuneFiche"] : $this->getContext($context, "aucuneFiche")), "html", null, true);
            echo "</h5></div>
    ";
        }
        // line 16
        echo "    
    
";
        
        $__internal_c91d0fe5b48d38162d32d4b7952127e619483bfee3588216bac32416d1cc842c->leave($__internal_c91d0fe5b48d38162d32d4b7952127e619483bfee3588216bac32416d1cc842c_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Comptable:VueValiderFrais.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 16,  105 => 14,  103 => 13,  98 => 11,  94 => 10,  90 => 9,  86 => 8,  82 => 7,  79 => 6,  73 => 5,  61 => 4,  49 => 3,  37 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehGsbBundle::base_accueil.html.twig' %}
{% block title %}Valider frais{% endblock %}
{% block titrePage %}Choisir un visiteur et un mois{% endblock %}
{% block validation_des_frais %}active{% endblock %}
{% block contenu %}
    
    {{ form_start(form) }}
    <div class=\"col-lg-3\">{{ form_widget(form.visiteurs) }}</div>
    <div class=\"col-lg-2\">{{ form_widget(form.mois) }}</div>
    <div class=\"col-lg-2\">{{ form_widget(form.voir) }}</div>
    {{ form_end(form) }} 
    
    {% if aucuneFiche is not empty %}
        <div class=\"col-lg-6\"><br><h5>{{aucuneFiche}}</h5></div>
    {% endif %}
    
    
{% endblock %}

", "mehGsbBundle:Comptable:VueValiderFrais.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Comptable/VueValiderFrais.html.twig");
    }
}
