<?php

/* mehGsbBundle:Commun:VueAuthentification.html.twig */
class __TwigTemplate_7ccc7ed51aa8d02a5d7948968c3ff4f5d340c85076d076f0be7a3a804c454d84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8543bd1108ee13b1e004d7e49a4d65e2cb469a136f6bc3997debe684e044f1a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8543bd1108ee13b1e004d7e49a4d65e2cb469a136f6bc3997debe684e044f1a6->enter($__internal_8543bd1108ee13b1e004d7e49a4d65e2cb469a136f6bc3997debe684e044f1a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Commun:VueAuthentification.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>GsbFrais - Authentification</title>

    ";
        // line 10
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "c2ac694_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_c2ac694_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/c2ac694_bootstrap.min_1.css");
            // line 11
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" />
    ";
        } else {
            // asset "c2ac694"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_c2ac694") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/c2ac694.css");
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" />
    ";
        }
        unset($context["asset_url"]);
        // line 13
        echo "
    ";
        // line 14
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "d7db011_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_d7db011_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/d7db011_signin_1.css");
            // line 15
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" />
    ";
        } else {
            // asset "d7db011"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_d7db011") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/d7db011.css");
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\" />
    ";
        }
        unset($context["asset_url"]);
        // line 17
        echo "  </head>

  <body>
      
    <div class=\"container\">
        
        <div class=\"form-signin\">
            ";
        // line 24
        if ( !twig_test_empty((isset($context["erreurNdc"]) ? $context["erreurNdc"] : $this->getContext($context, "erreurNdc")))) {
            // line 25
            echo "                <div class=\"alert alert-danger\" role=\"alert\"><b>Erreur : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurNdc"]) ? $context["erreurNdc"] : $this->getContext($context, "erreurNdc")), "html", null, true);
            echo "</div>
            ";
        }
        // line 27
        echo "            ";
        if ( !twig_test_empty((isset($context["erreurMdp"]) ? $context["erreurMdp"] : $this->getContext($context, "erreurMdp")))) {
            // line 28
            echo "                <div class=\"alert alert-danger\" role=\"alert\"><b>Erreur : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurMdp"]) ? $context["erreurMdp"] : $this->getContext($context, "erreurMdp")), "html", null, true);
            echo "</div>
            ";
        }
        // line 30
        echo "            <h2 class=\"form-signin-heading\">GSB</h2>
            ";
        // line 31
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formAuthentification"]) ? $context["formAuthentification"] : $this->getContext($context, "formAuthentification")), 'form_start');
        echo "
            ";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formAuthentification"]) ? $context["formAuthentification"] : $this->getContext($context, "formAuthentification")), "login", array()), 'widget');
        echo "
            ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formAuthentification"]) ? $context["formAuthentification"] : $this->getContext($context, "formAuthentification")), "mdp", array()), 'widget');
        echo "
            <table>
                <tr>
                    <td>";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formAuthentification"]) ? $context["formAuthentification"] : $this->getContext($context, "formAuthentification")), "valider", array()), 'widget');
        echo "</td>
                    <td>";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formAuthentification"]) ? $context["formAuthentification"] : $this->getContext($context, "formAuthentification")), "annuler", array()), 'widget');
        echo "</td>
                </tr>
            </table>
            ";
        // line 40
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formAuthentification"]) ? $context["formAuthentification"] : $this->getContext($context, "formAuthentification")), 'form_end');
        echo "
        </div>
        
    </div> 
    
  </body>
</html>

";
        
        $__internal_8543bd1108ee13b1e004d7e49a4d65e2cb469a136f6bc3997debe684e044f1a6->leave($__internal_8543bd1108ee13b1e004d7e49a4d65e2cb469a136f6bc3997debe684e044f1a6_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Commun:VueAuthentification.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 40,  119 => 37,  115 => 36,  109 => 33,  105 => 32,  101 => 31,  98 => 30,  92 => 28,  89 => 27,  83 => 25,  81 => 24,  72 => 17,  58 => 15,  54 => 14,  51 => 13,  37 => 11,  33 => 10,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>GsbFrais - Authentification</title>

    {% stylesheets '@mehGsbBundle/Resources/public/bootstrap/css/bootstrap.min.css' %}
    <link href=\"{{ asset_url }}\" rel=\"stylesheet\" />
    {% endstylesheets %}

    {% stylesheets '@mehGsbBundle/Resources/public/css/signin.css' %}
    <link href=\"{{ asset_url }}\" rel=\"stylesheet\" />
    {% endstylesheets %}
  </head>

  <body>
      
    <div class=\"container\">
        
        <div class=\"form-signin\">
            {% if erreurNdc is not empty %}
                <div class=\"alert alert-danger\" role=\"alert\"><b>Erreur : </b>{{erreurNdc}}</div>
            {% endif %}
            {% if erreurMdp is not empty %}
                <div class=\"alert alert-danger\" role=\"alert\"><b>Erreur : </b>{{erreurMdp}}</div>
            {% endif %}
            <h2 class=\"form-signin-heading\">GSB</h2>
            {{ form_start(formAuthentification) }}
            {{ form_widget(formAuthentification.login) }}
            {{ form_widget(formAuthentification.mdp) }}
            <table>
                <tr>
                    <td>{{ form_widget(formAuthentification.valider) }}</td>
                    <td>{{ form_widget(formAuthentification.annuler) }}</td>
                </tr>
            </table>
            {{ form_end(formAuthentification) }}
        </div>
        
    </div> 
    
  </body>
</html>

", "mehGsbBundle:Commun:VueAuthentification.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Commun/VueAuthentification.html.twig");
    }
}
