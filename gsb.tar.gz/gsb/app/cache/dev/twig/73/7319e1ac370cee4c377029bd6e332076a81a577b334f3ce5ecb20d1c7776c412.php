<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_1836f5646acab12a3568c7b2b95d071e22804b52adcd36dc6f1e9ea4c3d1358e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bee6f18b22f724f28a8691327c2006ddf9e5b6dc24ffea7599542530f1c26b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bee6f18b22f724f28a8691327c2006ddf9e5b6dc24ffea7599542530f1c26b3->enter($__internal_8bee6f18b22f724f28a8691327c2006ddf9e5b6dc24ffea7599542530f1c26b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8bee6f18b22f724f28a8691327c2006ddf9e5b6dc24ffea7599542530f1c26b3->leave($__internal_8bee6f18b22f724f28a8691327c2006ddf9e5b6dc24ffea7599542530f1c26b3_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ae420d8c9c4b495d0ec6251c13cb6f2b4fd7ce31dded241985cdb227faac0ab2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae420d8c9c4b495d0ec6251c13cb6f2b4fd7ce31dded241985cdb227faac0ab2->enter($__internal_ae420d8c9c4b495d0ec6251c13cb6f2b4fd7ce31dded241985cdb227faac0ab2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_ae420d8c9c4b495d0ec6251c13cb6f2b4fd7ce31dded241985cdb227faac0ab2->leave($__internal_ae420d8c9c4b495d0ec6251c13cb6f2b4fd7ce31dded241985cdb227faac0ab2_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_adca0e1d025216797a1ae6c61058ee21450442a5610725e3b3499500e8dce489 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_adca0e1d025216797a1ae6c61058ee21450442a5610725e3b3499500e8dce489->enter($__internal_adca0e1d025216797a1ae6c61058ee21450442a5610725e3b3499500e8dce489_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_adca0e1d025216797a1ae6c61058ee21450442a5610725e3b3499500e8dce489->leave($__internal_adca0e1d025216797a1ae6c61058ee21450442a5610725e3b3499500e8dce489_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'TwigBundle::layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/var/www/gsb/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
