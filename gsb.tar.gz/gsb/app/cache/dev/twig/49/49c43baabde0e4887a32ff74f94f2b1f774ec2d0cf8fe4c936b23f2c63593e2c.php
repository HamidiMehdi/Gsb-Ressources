<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_9c4532b687ee90212abfce8ef8d5b32bf055ab67a0105690ec66b7ef5795c646 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8e983a18fff81d5e938960419498f853b1fcae2f567ed02bdc5c90a348c05d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8e983a18fff81d5e938960419498f853b1fcae2f567ed02bdc5c90a348c05d5->enter($__internal_f8e983a18fff81d5e938960419498f853b1fcae2f567ed02bdc5c90a348c05d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_f8e983a18fff81d5e938960419498f853b1fcae2f567ed02bdc5c90a348c05d5->leave($__internal_f8e983a18fff81d5e938960419498f853b1fcae2f567ed02bdc5c90a348c05d5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'TwigBundle:Exception:error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/var/www/gsb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
