<?php

/* mehGsbBundle:Commun:VueChangerMdp.html.twig */
class __TwigTemplate_b23d0b6c877c12bc5a85f320750998c85b9be725f6e3fb1e774834bf5bf04618 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehGsbBundle::base_accueil.html.twig", "mehGsbBundle:Commun:VueChangerMdp.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_91293d7f5e4034643bacb579603024b001958b2ba12630c1ea4fc08524f3a8e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91293d7f5e4034643bacb579603024b001958b2ba12630c1ea4fc08524f3a8e8->enter($__internal_91293d7f5e4034643bacb579603024b001958b2ba12630c1ea4fc08524f3a8e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Commun:VueChangerMdp.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_91293d7f5e4034643bacb579603024b001958b2ba12630c1ea4fc08524f3a8e8->leave($__internal_91293d7f5e4034643bacb579603024b001958b2ba12630c1ea4fc08524f3a8e8_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_34e530a4b06566f0ac3551056eae08bf25411e79119e019541efad5d8bf816cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34e530a4b06566f0ac3551056eae08bf25411e79119e019541efad5d8bf816cf->enter($__internal_34e530a4b06566f0ac3551056eae08bf25411e79119e019541efad5d8bf816cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Changer mdp ";
        
        $__internal_34e530a4b06566f0ac3551056eae08bf25411e79119e019541efad5d8bf816cf->leave($__internal_34e530a4b06566f0ac3551056eae08bf25411e79119e019541efad5d8bf816cf_prof);

    }

    // line 3
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_b4643245dbd8af4eed61b6aaee7b826cdac3c92e969a122b9be3f9e4d9da86d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4643245dbd8af4eed61b6aaee7b826cdac3c92e969a122b9be3f9e4d9da86d0->enter($__internal_b4643245dbd8af4eed61b6aaee7b826cdac3c92e969a122b9be3f9e4d9da86d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Changer votre mot de passe";
        
        $__internal_b4643245dbd8af4eed61b6aaee7b826cdac3c92e969a122b9be3f9e4d9da86d0->leave($__internal_b4643245dbd8af4eed61b6aaee7b826cdac3c92e969a122b9be3f9e4d9da86d0_prof);

    }

    // line 4
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_67e3bcc0a06e52c9c670fe1c099567cdccffa6f56e7c2901426056dbf8c27055 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67e3bcc0a06e52c9c670fe1c099567cdccffa6f56e7c2901426056dbf8c27055->enter($__internal_67e3bcc0a06e52c9c670fe1c099567cdccffa6f56e7c2901426056dbf8c27055_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 5
        echo "       
    <div class=\"col-lg-8\">
    ";
        // line 7
        if ( !twig_test_empty((isset($context["erreurMdpActuel"]) ? $context["erreurMdpActuel"] : $this->getContext($context, "erreurMdpActuel")))) {
            // line 8
            echo "        <div class=\"alert alert-danger\" role=\"alert\"><center><b>Erreur : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurMdpActuel"]) ? $context["erreurMdpActuel"] : $this->getContext($context, "erreurMdpActuel")), "html", null, true);
            echo "</center></div>
    ";
        }
        // line 10
        echo "    ";
        if ( !twig_test_empty((isset($context["erreurNewMdp"]) ? $context["erreurNewMdp"] : $this->getContext($context, "erreurNewMdp")))) {
            // line 11
            echo "        <div class=\"alert alert-warning\" role=\"alert\"><center><b>Attention : </b>";
            echo twig_escape_filter($this->env, (isset($context["erreurNewMdp"]) ? $context["erreurNewMdp"] : $this->getContext($context, "erreurNewMdp")), "html", null, true);
            echo "</center></div>
    ";
        }
        // line 13
        echo "    ";
        if ( !twig_test_empty((isset($context["succes"]) ? $context["succes"] : $this->getContext($context, "succes")))) {
            // line 14
            echo "        <div class=\"alert alert-success\" role=\"alert\"><center><b>Succès : </b>";
            echo twig_escape_filter($this->env, (isset($context["succes"]) ? $context["succes"] : $this->getContext($context, "succes")), "html", null, true);
            echo "</center></div>
    ";
        }
        // line 16
        echo "        ";
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formMdp"]) ? $context["formMdp"] : $this->getContext($context, "formMdp")), 'form');
        echo "
    </div>

";
        
        $__internal_67e3bcc0a06e52c9c670fe1c099567cdccffa6f56e7c2901426056dbf8c27055->leave($__internal_67e3bcc0a06e52c9c670fe1c099567cdccffa6f56e7c2901426056dbf8c27055_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Commun:VueChangerMdp.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 16,  90 => 14,  87 => 13,  81 => 11,  78 => 10,  72 => 8,  70 => 7,  66 => 5,  60 => 4,  48 => 3,  36 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehGsbBundle::base_accueil.html.twig' %}
{% block title %}Changer mdp {% endblock %}
{% block titrePage %}Changer votre mot de passe{% endblock %}
{% block contenu %}
       
    <div class=\"col-lg-8\">
    {% if erreurMdpActuel is not empty %}
        <div class=\"alert alert-danger\" role=\"alert\"><center><b>Erreur : </b>{{erreurMdpActuel}}</center></div>
    {% endif %}
    {% if erreurNewMdp is not empty %}
        <div class=\"alert alert-warning\" role=\"alert\"><center><b>Attention : </b>{{erreurNewMdp}}</center></div>
    {% endif %}
    {% if succes is not empty %}
        <div class=\"alert alert-success\" role=\"alert\"><center><b>Succès : </b>{{succes}}</center></div>
    {% endif %}
        {{ form(formMdp) }}
    </div>

{% endblock %}", "mehGsbBundle:Commun:VueChangerMdp.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Commun/VueChangerMdp.html.twig");
    }
}
