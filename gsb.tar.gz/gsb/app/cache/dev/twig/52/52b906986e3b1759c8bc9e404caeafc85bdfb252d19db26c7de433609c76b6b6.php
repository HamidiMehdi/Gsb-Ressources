<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_a2a8243de58c9800337b8c5ba50ca5b81b2ad02532b0a1b7fd6147755f477567 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_188e8b32636f34a2ed8ec6ec6d72b47df6cc7fb6719fd109933a199b9b9a1524 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_188e8b32636f34a2ed8ec6ec6d72b47df6cc7fb6719fd109933a199b9b9a1524->enter($__internal_188e8b32636f34a2ed8ec6ec6d72b47df6cc7fb6719fd109933a199b9b9a1524_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_188e8b32636f34a2ed8ec6ec6d72b47df6cc7fb6719fd109933a199b9b9a1524->leave($__internal_188e8b32636f34a2ed8ec6ec6d72b47df6cc7fb6719fd109933a199b9b9a1524_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'TwigBundle:Exception:error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/var/www/gsb/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
