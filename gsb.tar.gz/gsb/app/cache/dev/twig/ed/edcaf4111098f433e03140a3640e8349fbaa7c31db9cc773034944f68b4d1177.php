<?php

/* mehGsbBundle:Visiteur:VueConsulterFicheFrais.html.twig */
class __TwigTemplate_bcc66a2a262bd88bfc95b87ac31d4d6da2e9a3daa1378518aac4c8f59906aca8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehGsbBundle::base_accueil.html.twig", "mehGsbBundle:Visiteur:VueConsulterFicheFrais.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'consulter_fiche_de_frais' => array($this, 'block_consulter_fiche_de_frais'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_87874ecbf619f366ac3b2fdaa7d7f952b3433e9a5ea00a8c29d7e1e76a21917f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87874ecbf619f366ac3b2fdaa7d7f952b3433e9a5ea00a8c29d7e1e76a21917f->enter($__internal_87874ecbf619f366ac3b2fdaa7d7f952b3433e9a5ea00a8c29d7e1e76a21917f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Visiteur:VueConsulterFicheFrais.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_87874ecbf619f366ac3b2fdaa7d7f952b3433e9a5ea00a8c29d7e1e76a21917f->leave($__internal_87874ecbf619f366ac3b2fdaa7d7f952b3433e9a5ea00a8c29d7e1e76a21917f_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_ead75c43ee209a18b937ff19805a4ad3ca156d60e68a40cafc3a5485e5c8fccf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ead75c43ee209a18b937ff19805a4ad3ca156d60e68a40cafc3a5485e5c8fccf->enter($__internal_ead75c43ee209a18b937ff19805a4ad3ca156d60e68a40cafc3a5485e5c8fccf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Consulter fiche de frais ";
        
        $__internal_ead75c43ee209a18b937ff19805a4ad3ca156d60e68a40cafc3a5485e5c8fccf->leave($__internal_ead75c43ee209a18b937ff19805a4ad3ca156d60e68a40cafc3a5485e5c8fccf_prof);

    }

    // line 3
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_f0f8211199e274e68822f8e1575f4942f18c847202d14bf87508aea4140624dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0f8211199e274e68822f8e1575f4942f18c847202d14bf87508aea4140624dc->enter($__internal_f0f8211199e274e68822f8e1575f4942f18c847202d14bf87508aea4140624dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Consulter fiche de frais";
        
        $__internal_f0f8211199e274e68822f8e1575f4942f18c847202d14bf87508aea4140624dc->leave($__internal_f0f8211199e274e68822f8e1575f4942f18c847202d14bf87508aea4140624dc_prof);

    }

    // line 4
    public function block_consulter_fiche_de_frais($context, array $blocks = array())
    {
        $__internal_f55f9e778207915afbaef67723d0b0303f43412e89302c5c0e1df41b22dbafc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f55f9e778207915afbaef67723d0b0303f43412e89302c5c0e1df41b22dbafc9->enter($__internal_f55f9e778207915afbaef67723d0b0303f43412e89302c5c0e1df41b22dbafc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "consulter_fiche_de_frais"));

        echo "active";
        
        $__internal_f55f9e778207915afbaef67723d0b0303f43412e89302c5c0e1df41b22dbafc9->leave($__internal_f55f9e778207915afbaef67723d0b0303f43412e89302c5c0e1df41b22dbafc9_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_756551ca1796c04581f73aac41e020cf17e792c041e219fcda4a6ceb85ac8bbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_756551ca1796c04581f73aac41e020cf17e792c041e219fcda4a6ceb85ac8bbf->enter($__internal_756551ca1796c04581f73aac41e020cf17e792c041e219fcda4a6ceb85ac8bbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "
    ";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    <div class=\"col-lg-3\">";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "datesPossibles", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "voir", array()), 'widget');
        echo "</div>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo " 
    
    ";
        // line 12
        if ((twig_length_filter($this->env, (isset($context["fraisForfait"]) ? $context["fraisForfait"] : $this->getContext($context, "fraisForfait"))) >= 1)) {
            // line 13
            echo "    <br><br><br>
    <div class=\"col-lg-12\"><h3>Frais Forfait</h3></div>
    <div class=\"col-lg-6\">

        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Repas midi</th>
                    <th>Nuitée</th>
                    <th>Etape</th>
                    <th>Km</th>
                    <th>Situation</th>
                </tr>
            </thead>
            <tbody>
                    <tr>
                        <td> ";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fraisForfait"]) ? $context["fraisForfait"] : $this->getContext($context, "fraisForfait")), "repasMidi", array(), "array"), "html", null, true);
            echo " </td>
                        <td> ";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fraisForfait"]) ? $context["fraisForfait"] : $this->getContext($context, "fraisForfait")), "nuitee", array(), "array"), "html", null, true);
            echo " </td>
                        <td> ";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fraisForfait"]) ? $context["fraisForfait"] : $this->getContext($context, "fraisForfait")), "etape", array(), "array"), "html", null, true);
            echo " </td>
                        <td> ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fraisForfait"]) ? $context["fraisForfait"] : $this->getContext($context, "fraisForfait")), "km", array(), "array"), "html", null, true);
            echo " </td>
                        <td> ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fraisForfait"]) ? $context["fraisForfait"] : $this->getContext($context, "fraisForfait")), "etat", array(), "array"), "html", null, true);
            echo " </td>
                    </tr>
            </tbody>
        </table>
    </div>
    ";
        }
        // line 39
        echo "
    ";
        // line 40
        if ((twig_length_filter($this->env, (isset($context["horsForfait"]) ? $context["horsForfait"] : $this->getContext($context, "horsForfait"))) >= 1)) {
            // line 41
            echo "    <br>
    <div class=\"col-lg-12\"><h3>Hors Forfait</h3></div>
    <div class=\"col-lg-6\">
        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Libelle</th>
                    <th>Montant</th>
                    <th>Etat</th>
                </tr>
            </thead>
            <tbody>
                ";
            // line 54
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["horsForfait"]) ? $context["horsForfait"] : $this->getContext($context, "horsForfait")));
            foreach ($context['_seq'] as $context["_key"] => $context["unHorsForfait"]) {
                // line 55
                echo "                    <tr>
                        <td> ";
                // line 56
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unHorsForfait"], "datefrais", array()), "d/m/Y"), "html", null, true);
                echo " </td>
                        <td> ";
                // line 57
                echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "libelle", array()), "html", null, true);
                echo " </td>
                        <td> ";
                // line 58
                echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "montant", array()), "html", null, true);
                echo " </td>
                        <td> ";
                // line 59
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unHorsForfait"], "idetat", array()), "libelle", array()), "html", null, true);
                echo " </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unHorsForfait'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 61
            echo "   
            </tbody>
        </table>
    </div>
    ";
        }
        // line 66
        echo "
    ";
        // line 67
        if ((twig_length_filter($this->env, (isset($context["ficheFrais"]) ? $context["ficheFrais"] : $this->getContext($context, "ficheFrais"))) >= 1)) {
            // line 68
            echo "    <br>
    <div class=\"col-lg-12\"><h3>Hors Classification</h3></div>
    <div class=\"col-lg-6\">
        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Nombre justificatif</th>
                    <th>Montant total</th>
                    <th>Situation</th>
                </tr>
            </thead>
            <tbody>
                    <tr>
                        <td> ";
            // line 81
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["ficheFrais"]) ? $context["ficheFrais"] : $this->getContext($context, "ficheFrais")), "nbJustificatifs", array()), "html", null, true);
            echo " </td>
                        <td> ";
            // line 82
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["ficheFrais"]) ? $context["ficheFrais"] : $this->getContext($context, "ficheFrais")), "montantvalide", array()), "html", null, true);
            echo " </td>
                        <td> ";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["ficheFrais"]) ? $context["ficheFrais"] : $this->getContext($context, "ficheFrais")), "idetatfraishorsclassification", array()), "libelle", array()), "html", null, true);
            echo " </td>
                    </tr>  
            </tbody>
        </table>
    </div>
    ";
        }
        // line 89
        echo "
";
        
        $__internal_756551ca1796c04581f73aac41e020cf17e792c041e219fcda4a6ceb85ac8bbf->leave($__internal_756551ca1796c04581f73aac41e020cf17e792c041e219fcda4a6ceb85ac8bbf_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Visiteur:VueConsulterFicheFrais.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  236 => 89,  227 => 83,  223 => 82,  219 => 81,  204 => 68,  202 => 67,  199 => 66,  192 => 61,  183 => 59,  179 => 58,  175 => 57,  171 => 56,  168 => 55,  164 => 54,  149 => 41,  147 => 40,  144 => 39,  135 => 33,  131 => 32,  127 => 31,  123 => 30,  119 => 29,  101 => 13,  99 => 12,  94 => 10,  90 => 9,  86 => 8,  82 => 7,  79 => 6,  73 => 5,  61 => 4,  49 => 3,  37 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehGsbBundle::base_accueil.html.twig' %}
{% block title %}Consulter fiche de frais {% endblock %}
{% block titrePage %}Consulter fiche de frais{% endblock %}
{% block consulter_fiche_de_frais %}active{% endblock %}
{% block contenu %}

    {{ form_start(form) }}
    <div class=\"col-lg-3\">{{ form_widget(form.datesPossibles) }}</div>
    <div class=\"col-lg-2\">{{ form_widget(form.voir) }}</div>
    {{ form_end(form) }} 
    
    {% if fraisForfait|length >=1%}
    <br><br><br>
    <div class=\"col-lg-12\"><h3>Frais Forfait</h3></div>
    <div class=\"col-lg-6\">

        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Repas midi</th>
                    <th>Nuitée</th>
                    <th>Etape</th>
                    <th>Km</th>
                    <th>Situation</th>
                </tr>
            </thead>
            <tbody>
                    <tr>
                        <td> {{fraisForfait['repasMidi']}} </td>
                        <td> {{fraisForfait['nuitee']}} </td>
                        <td> {{fraisForfait['etape']}} </td>
                        <td> {{fraisForfait['km']}} </td>
                        <td> {{fraisForfait['etat']}} </td>
                    </tr>
            </tbody>
        </table>
    </div>
    {% endif%}

    {% if horsForfait|length >=1%}
    <br>
    <div class=\"col-lg-12\"><h3>Hors Forfait</h3></div>
    <div class=\"col-lg-6\">
        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Libelle</th>
                    <th>Montant</th>
                    <th>Etat</th>
                </tr>
            </thead>
            <tbody>
                {% for unHorsForfait in horsForfait%}
                    <tr>
                        <td> {{unHorsForfait.datefrais|date('d/m/Y')}} </td>
                        <td> {{unHorsForfait.libelle}} </td>
                        <td> {{unHorsForfait.montant}} </td>
                        <td> {{unHorsForfait.idetat.libelle}} </td>
                    </tr>
                {% endfor %}   
            </tbody>
        </table>
    </div>
    {% endif%}

    {% if ficheFrais|length >=1%}
    <br>
    <div class=\"col-lg-12\"><h3>Hors Classification</h3></div>
    <div class=\"col-lg-6\">
        <table class=\"table table-striped\">
            <thead>
                <tr>
                    <th>Nombre justificatif</th>
                    <th>Montant total</th>
                    <th>Situation</th>
                </tr>
            </thead>
            <tbody>
                    <tr>
                        <td> {{ficheFrais.nbJustificatifs}} </td>
                        <td> {{ficheFrais.montantvalide}} </td>
                        <td> {{ficheFrais.idetatfraishorsclassification.libelle}} </td>
                    </tr>  
            </tbody>
        </table>
    </div>
    {% endif %}

{% endblock %}", "mehGsbBundle:Visiteur:VueConsulterFicheFrais.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Visiteur/VueConsulterFicheFrais.html.twig");
    }
}
