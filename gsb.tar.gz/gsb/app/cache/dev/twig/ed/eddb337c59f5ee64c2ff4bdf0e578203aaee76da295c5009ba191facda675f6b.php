<?php

/* mehGsbBundle:Comptable:VueValiderFraisDunVisiteur.html.twig */
class __TwigTemplate_595942b38161c55511fa92a38ec82db12aa502a96823de0796a0931efc2a54af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehGsbBundle::base_accueil.html.twig", "mehGsbBundle:Comptable:VueValiderFraisDunVisiteur.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'validation_des_frais' => array($this, 'block_validation_des_frais'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a50ccf57e5f1e1c3ef3908dd36a27376595aa9e82eb4c6240386ef685e1f5ecf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a50ccf57e5f1e1c3ef3908dd36a27376595aa9e82eb4c6240386ef685e1f5ecf->enter($__internal_a50ccf57e5f1e1c3ef3908dd36a27376595aa9e82eb4c6240386ef685e1f5ecf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Comptable:VueValiderFraisDunVisiteur.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a50ccf57e5f1e1c3ef3908dd36a27376595aa9e82eb4c6240386ef685e1f5ecf->leave($__internal_a50ccf57e5f1e1c3ef3908dd36a27376595aa9e82eb4c6240386ef685e1f5ecf_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_4b0f191910f7bb459ec31a63aac6039484fa7bb9565b6576c2e6c85587628484 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b0f191910f7bb459ec31a63aac6039484fa7bb9565b6576c2e6c85587628484->enter($__internal_4b0f191910f7bb459ec31a63aac6039484fa7bb9565b6576c2e6c85587628484_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Valider frais";
        
        $__internal_4b0f191910f7bb459ec31a63aac6039484fa7bb9565b6576c2e6c85587628484->leave($__internal_4b0f191910f7bb459ec31a63aac6039484fa7bb9565b6576c2e6c85587628484_prof);

    }

    // line 3
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_86d639bfcad3e22d4205d5742dd445cee964fcaa08343114875b6379020bd1fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86d639bfcad3e22d4205d5742dd445cee964fcaa08343114875b6379020bd1fb->enter($__internal_86d639bfcad3e22d4205d5742dd445cee964fcaa08343114875b6379020bd1fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Valider la fiche frais de ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["visiteur"]) ? $context["visiteur"] : $this->getContext($context, "visiteur")), "nom", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["visiteur"]) ? $context["visiteur"] : $this->getContext($context, "visiteur")), "prenom", array()), "html", null, true);
        
        $__internal_86d639bfcad3e22d4205d5742dd445cee964fcaa08343114875b6379020bd1fb->leave($__internal_86d639bfcad3e22d4205d5742dd445cee964fcaa08343114875b6379020bd1fb_prof);

    }

    // line 4
    public function block_validation_des_frais($context, array $blocks = array())
    {
        $__internal_3c61edc32b9ede35d7d29c1dea40441e049a9dd18b06004875eb66773dd3f705 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c61edc32b9ede35d7d29c1dea40441e049a9dd18b06004875eb66773dd3f705->enter($__internal_3c61edc32b9ede35d7d29c1dea40441e049a9dd18b06004875eb66773dd3f705_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "validation_des_frais"));

        echo "active";
        
        $__internal_3c61edc32b9ede35d7d29c1dea40441e049a9dd18b06004875eb66773dd3f705->leave($__internal_3c61edc32b9ede35d7d29c1dea40441e049a9dd18b06004875eb66773dd3f705_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_861122675511a7c0913e138d294eaf82e4df8f41f4e1ee66a599bd804c131fb9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_861122675511a7c0913e138d294eaf82e4df8f41f4e1ee66a599bd804c131fb9->enter($__internal_861122675511a7c0913e138d294eaf82e4df8f41f4e1ee66a599bd804c131fb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        echo "<br>
    
    ";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), 'form_start');
        echo "
    <div><h3> Frais Forfait :</h3></div>
    <div class=\"col-lg-2\">";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "repasMidi", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "repasMidi", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-1\">";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "nuitee", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "nuitee", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-1\">";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "etape", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "etape", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-1\">";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "km", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "km", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "etat", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "etat", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-4\"><br>";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "valider", array()), 'widget');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), "annuler", array()), 'widget');
        echo "</div>
    ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formFraisForfait"]) ? $context["formFraisForfait"] : $this->getContext($context, "formFraisForfait")), 'form_end');
        echo "   
    
    <br><br><br><br><br>
    <div><h3> Frais Hors Forfait :</h3></div>
    <table width=100% class='table-hover' >
        <thead>
        <tr>
            <th>Date</th>
            <th>Libelle</th>
            <th>Montant</th>
            <th>Situation</th>
        </tr>
        </thead>
        <tbody>
    ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesHorsForfait"]) ? $context["lesHorsForfait"] : $this->getContext($context, "lesHorsForfait")));
        foreach ($context['_seq'] as $context["_key"] => $context["unHorsForfait"]) {
            // line 30
            echo "        <tr>
            <td> ";
            // line 31
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unHorsForfait"], "datefrais", array()), "d/m/Y"), "html", null, true);
            echo " </td>
            <td> ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "libelle", array()), "html", null, true);
            echo " </td>
            <td> ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["unHorsForfait"], "montant", array()), "html", null, true);
            echo " </td>
            <td> ";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unHorsForfait"], "idetat", array()), "libelle", array()), "html", null, true);
            echo " </td>
            <td><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("updateEtatHorsForfait", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")), "idEtat" => 3, "idHorsForfait" => $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()))), "html", null, true);
            echo "\"><button class='btn btn-primary'>Validée</button></a></td>
            <td><a href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("updateEtatHorsForfait", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")), "idEtat" => 4, "idHorsForfait" => $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()))), "html", null, true);
            echo "\"><button class='btn btn-primary'>Mise en paiement</button></a></td>
            <td><a href=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("updateEtatHorsForfait", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")), "idEtat" => 5, "idHorsForfait" => $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()))), "html", null, true);
            echo "\"><button class='btn btn-primary'>Rembousée</button></a></td>
            <td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("updateEtatHorsForfait", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")), "idEtat" => 6, "idHorsForfait" => $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()))), "html", null, true);
            echo "\"><button class='btn btn-primary'>Enregistré</button></a></td>
            ";
            // line 39
            if (($this->getAttribute($context["unHorsForfait"], "refuser", array()) == false)) {
                // line 40
                echo "            <td><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("updateLibelleHorsForfait", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")), "idHorsForfait" => $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()), "btn" => 1)), "html", null, true);
                echo "\"><button class='btn btn-danger'>Refuser</button></a></td>
            ";
            }
            // line 42
            echo "            ";
            if (($this->getAttribute($context["unHorsForfait"], "refuser", array()) == true)) {
                // line 43
                echo "            <td><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("updateLibelleHorsForfait", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")), "idHorsForfait" => $this->getAttribute($context["unHorsForfait"], "idlignefraishorsforfait", array()), "btn" => 2)), "html", null, true);
                echo "\"><button class='btn btn-danger'>Annuler le refus</button></a></td>
            ";
            }
            // line 45
            echo "        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unHorsForfait'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "        </tbody>
    </table>
    
    ";
        // line 50
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), 'form_start');
        echo "
    <br><br>
    <div><h3> Hors Classification :</h3></div>
    <div class=\"col-lg-2\">";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "justificatif", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "justificatif", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "montant", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "montant", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-2\">";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "etat", array()), 'label');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "etat", array()), 'widget');
        echo "</div>
    <div class=\"col-lg-4\"><br>";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "ajouter", array()), 'widget');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), "annuler", array()), 'widget');
        echo "</div>
    ";
        // line 57
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["formHorsClassification"]) ? $context["formHorsClassification"] : $this->getContext($context, "formHorsClassification")), 'form_end');
        echo "
    
    
    <br><br><br><br>
    <hr>
    ";
        // line 62
        if (($this->getAttribute($this->getAttribute((isset($context["ficheFrais"]) ? $context["ficheFrais"] : $this->getContext($context, "ficheFrais")), "idetatfiche", array()), "idetat", array()) != 3)) {
            // line 63
            echo "    <div class='col-lg-4'></div>
    <div class=\"col-lg-4\">
        <a class=\"btn btn-primary btn-lg btn-block login-button\" href=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("validerFicheFrais", array("idFiche" => (isset($context["idFiche"]) ? $context["idFiche"] : $this->getContext($context, "idFiche")))), "html", null, true);
            echo "\"> Valider la fiche </a>
    </div>
    ";
        } else {
            // line 68
            echo "    <div class='col-lg-4'></div>
    <div class=\"col-lg-4\">
        <a class=\"btn btn-primary btn-lg btn-block login-button\" disabled> Fiche deja validé </a>
    </div>
    ";
        }
        // line 73
        echo "    
    
    
";
        
        $__internal_861122675511a7c0913e138d294eaf82e4df8f41f4e1ee66a599bd804c131fb9->leave($__internal_861122675511a7c0913e138d294eaf82e4df8f41f4e1ee66a599bd804c131fb9_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Comptable:VueValiderFraisDunVisiteur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 73,  253 => 68,  247 => 65,  243 => 63,  241 => 62,  233 => 57,  227 => 56,  222 => 55,  217 => 54,  212 => 53,  206 => 50,  201 => 47,  194 => 45,  188 => 43,  185 => 42,  179 => 40,  177 => 39,  173 => 38,  169 => 37,  165 => 36,  161 => 35,  157 => 34,  153 => 33,  149 => 32,  145 => 31,  142 => 30,  138 => 29,  121 => 15,  115 => 14,  110 => 13,  105 => 12,  100 => 11,  95 => 10,  90 => 9,  85 => 7,  76 => 5,  64 => 4,  49 => 3,  37 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehGsbBundle::base_accueil.html.twig' %}
{% block title %}Valider frais{% endblock %}
{% block titrePage %}Valider la fiche frais de {{visiteur.nom}} {{visiteur.prenom}}{% endblock %}
{% block validation_des_frais %}active{% endblock %}
{% block contenu %}<br>
    
    {{ form_start(formFraisForfait) }}
    <div><h3> Frais Forfait :</h3></div>
    <div class=\"col-lg-2\">{{ form_label(formFraisForfait.repasMidi) }}{{ form_widget(formFraisForfait.repasMidi) }}</div>
    <div class=\"col-lg-1\">{{ form_label(formFraisForfait.nuitee) }}{{ form_widget(formFraisForfait.nuitee) }}</div>
    <div class=\"col-lg-1\">{{ form_label(formFraisForfait.etape) }}{{ form_widget(formFraisForfait.etape) }}</div>
    <div class=\"col-lg-1\">{{ form_label(formFraisForfait.km) }}{{ form_widget(formFraisForfait.km) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formFraisForfait.etat) }}{{ form_widget(formFraisForfait.etat) }}</div>
    <div class=\"col-lg-4\"><br>{{ form_widget(formFraisForfait.valider) }} {{ form_widget(formFraisForfait.annuler) }}</div>
    {{ form_end(formFraisForfait) }}   
    
    <br><br><br><br><br>
    <div><h3> Frais Hors Forfait :</h3></div>
    <table width=100% class='table-hover' >
        <thead>
        <tr>
            <th>Date</th>
            <th>Libelle</th>
            <th>Montant</th>
            <th>Situation</th>
        </tr>
        </thead>
        <tbody>
    {% for unHorsForfait in lesHorsForfait%}
        <tr>
            <td> {{unHorsForfait.datefrais|date('d/m/Y') }} </td>
            <td> {{unHorsForfait.libelle}} </td>
            <td> {{unHorsForfait.montant}} </td>
            <td> {{unHorsForfait.idetat.libelle}} </td>
            <td><a href=\"{{path('updateEtatHorsForfait', {'idFiche': idFiche , 'idEtat': 3, 'idHorsForfait': unHorsForfait.idlignefraishorsforfait })}}\"><button class='btn btn-primary'>Validée</button></a></td>
            <td><a href=\"{{path('updateEtatHorsForfait', {'idFiche': idFiche , 'idEtat': 4, 'idHorsForfait': unHorsForfait.idlignefraishorsforfait })}}\"><button class='btn btn-primary'>Mise en paiement</button></a></td>
            <td><a href=\"{{path('updateEtatHorsForfait', {'idFiche': idFiche , 'idEtat': 5, 'idHorsForfait': unHorsForfait.idlignefraishorsforfait })}}\"><button class='btn btn-primary'>Rembousée</button></a></td>
            <td><a href=\"{{path('updateEtatHorsForfait', {'idFiche': idFiche , 'idEtat': 6, 'idHorsForfait': unHorsForfait.idlignefraishorsforfait })}}\"><button class='btn btn-primary'>Enregistré</button></a></td>
            {% if unHorsForfait.refuser == false %}
            <td><a href=\"{{path('updateLibelleHorsForfait', {'idFiche': idFiche, 'idHorsForfait': unHorsForfait.idlignefraishorsforfait, btn: 1 })}}\"><button class='btn btn-danger'>Refuser</button></a></td>
            {% endif %}
            {% if unHorsForfait.refuser == true %}
            <td><a href=\"{{path('updateLibelleHorsForfait', {'idFiche': idFiche, 'idHorsForfait': unHorsForfait.idlignefraishorsforfait, btn: 2 })}}\"><button class='btn btn-danger'>Annuler le refus</button></a></td>
            {% endif %}
        </tr>
    {% endfor %}
        </tbody>
    </table>
    
    {{ form_start(formHorsClassification) }}
    <br><br>
    <div><h3> Hors Classification :</h3></div>
    <div class=\"col-lg-2\">{{ form_label(formHorsClassification.justificatif) }}{{ form_widget(formHorsClassification.justificatif) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formHorsClassification.montant) }}{{ form_widget(formHorsClassification.montant) }}</div>
    <div class=\"col-lg-2\">{{ form_label(formHorsClassification.etat) }}{{ form_widget(formHorsClassification.etat) }}</div>
    <div class=\"col-lg-4\"><br>{{ form_widget(formHorsClassification.ajouter) }} {{ form_widget(formHorsClassification.annuler) }}</div>
    {{ form_end(formHorsClassification) }}
    
    
    <br><br><br><br>
    <hr>
    {% if ficheFrais.idetatfiche.idetat != 3 %}
    <div class='col-lg-4'></div>
    <div class=\"col-lg-4\">
        <a class=\"btn btn-primary btn-lg btn-block login-button\" href=\"{{path('validerFicheFrais', {'idFiche': idFiche })}}\"> Valider la fiche </a>
    </div>
    {% else %}
    <div class='col-lg-4'></div>
    <div class=\"col-lg-4\">
        <a class=\"btn btn-primary btn-lg btn-block login-button\" disabled> Fiche deja validé </a>
    </div>
    {% endif %}
    
    
    
{% endblock %}", "mehGsbBundle:Comptable:VueValiderFraisDunVisiteur.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Comptable/VueValiderFraisDunVisiteur.html.twig");
    }
}
