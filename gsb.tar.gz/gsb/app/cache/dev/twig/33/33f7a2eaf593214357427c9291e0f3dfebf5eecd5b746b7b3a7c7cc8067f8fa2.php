<?php

/* mehGsbBundle:Commun:VueAccueil.html.twig */
class __TwigTemplate_1783d8af76438e13514546f9a96164cd3547ca0c171cec30b933a3ad2d2357a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("mehGsbBundle::base_accueil.html.twig", "mehGsbBundle:Commun:VueAccueil.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titrePage' => array($this, 'block_titrePage'),
            'accueil' => array($this, 'block_accueil'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a9b95da4a845087bb4cd090b4f3b4c8a07714fce3d52a55da3d16ee4b65b04d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a9b95da4a845087bb4cd090b4f3b4c8a07714fce3d52a55da3d16ee4b65b04d->enter($__internal_8a9b95da4a845087bb4cd090b4f3b4c8a07714fce3d52a55da3d16ee4b65b04d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle:Commun:VueAccueil.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8a9b95da4a845087bb4cd090b4f3b4c8a07714fce3d52a55da3d16ee4b65b04d->leave($__internal_8a9b95da4a845087bb4cd090b4f3b4c8a07714fce3d52a55da3d16ee4b65b04d_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_eef13e45b8c788d30255ddc4deaa785bf0300f7f3041dbe381ce0ab0ad2044fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eef13e45b8c788d30255ddc4deaa785bf0300f7f3041dbe381ce0ab0ad2044fb->enter($__internal_eef13e45b8c788d30255ddc4deaa785bf0300f7f3041dbe381ce0ab0ad2044fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Accueil ";
        
        $__internal_eef13e45b8c788d30255ddc4deaa785bf0300f7f3041dbe381ce0ab0ad2044fb->leave($__internal_eef13e45b8c788d30255ddc4deaa785bf0300f7f3041dbe381ce0ab0ad2044fb_prof);

    }

    // line 3
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_974a290806629882be7e591bc39398c16ea29c7630f9127c30c9640ea342c61e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_974a290806629882be7e591bc39398c16ea29c7630f9127c30c9640ea342c61e->enter($__internal_974a290806629882be7e591bc39398c16ea29c7630f9127c30c9640ea342c61e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        echo "Accueil";
        
        $__internal_974a290806629882be7e591bc39398c16ea29c7630f9127c30c9640ea342c61e->leave($__internal_974a290806629882be7e591bc39398c16ea29c7630f9127c30c9640ea342c61e_prof);

    }

    // line 4
    public function block_accueil($context, array $blocks = array())
    {
        $__internal_00d5a63cf06008054206500ec24592e719e3c0430ffb18b5b9781f65f133ec7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00d5a63cf06008054206500ec24592e719e3c0430ffb18b5b9781f65f133ec7c->enter($__internal_00d5a63cf06008054206500ec24592e719e3c0430ffb18b5b9781f65f133ec7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "accueil"));

        echo "active";
        
        $__internal_00d5a63cf06008054206500ec24592e719e3c0430ffb18b5b9781f65f133ec7c->leave($__internal_00d5a63cf06008054206500ec24592e719e3c0430ffb18b5b9781f65f133ec7c_prof);

    }

    // line 5
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_811d7bcd5d9d2931bb9844d73ad1f07d988bf4bac473cf6079a59f1176c31b93 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_811d7bcd5d9d2931bb9844d73ad1f07d988bf4bac473cf6079a59f1176c31b93->enter($__internal_811d7bcd5d9d2931bb9844d73ad1f07d988bf4bac473cf6079a59f1176c31b93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        // line 6
        echo "       
    
    <center>
              
              <h4>Bonjour ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "prenom"), "method"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "nom"), "method"), "html", null, true);
        echo "  </h4>
              <span class=\"text-muted\">Nom : ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "nom"), "method"), "html", null, true);
        echo " </span><br/>
              <span class=\"text-muted\">Prenom : ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "prenom"), "method"), "html", null, true);
        echo "</span><br/>
              ";
        // line 13
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "menuComptable"), "method") == "activer")) {
            // line 14
            echo "                <span class=\"text-muted\">Profil : Comptable</span>
              ";
        }
        // line 16
        echo "              ";
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "menuVisiteur"), "method") == "activer")) {
            // line 17
            echo "                <span class=\"text-muted\">Profil : Visiteur médical</span>
              ";
        }
        // line 19
        echo "              
                          
    </center>      
        

";
        
        $__internal_811d7bcd5d9d2931bb9844d73ad1f07d988bf4bac473cf6079a59f1176c31b93->leave($__internal_811d7bcd5d9d2931bb9844d73ad1f07d988bf4bac473cf6079a59f1176c31b93_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle:Commun:VueAccueil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 19,  108 => 17,  105 => 16,  101 => 14,  99 => 13,  95 => 12,  91 => 11,  85 => 10,  79 => 6,  73 => 5,  61 => 4,  49 => 3,  37 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'mehGsbBundle::base_accueil.html.twig' %}
{% block title %}Accueil {% endblock %}
{% block titrePage %}Accueil{% endblock %}
{% block accueil %}active{% endblock %}
{% block contenu %}
       
    
    <center>
              
              <h4>Bonjour {{app.session.get('prenom')}} {{app.session.get('nom')}}  </h4>
              <span class=\"text-muted\">Nom : {{app.session.get('nom')}} </span><br/>
              <span class=\"text-muted\">Prenom : {{app.session.get('prenom')}}</span><br/>
              {% if app.session.get('menuComptable') == \"activer\" %}
                <span class=\"text-muted\">Profil : Comptable</span>
              {% endif %}
              {% if app.session.get('menuVisiteur') == \"activer\" %}
                <span class=\"text-muted\">Profil : Visiteur médical</span>
              {% endif %}
              
                          
    </center>      
        

{% endblock %}", "mehGsbBundle:Commun:VueAccueil.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/Commun/VueAccueil.html.twig");
    }
}
