<?php

/* mehGsbBundle::base_accueil.html.twig */
class __TwigTemplate_ffa844f136909451cd4213caa56218a4a8b51b84d04a8569dfaa32c2248e9971 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'accueil' => array($this, 'block_accueil'),
            'saisie_fiche_de_frais' => array($this, 'block_saisie_fiche_de_frais'),
            'consulter_fiche_de_frais' => array($this, 'block_consulter_fiche_de_frais'),
            'validation_des_frais' => array($this, 'block_validation_des_frais'),
            'titrePage' => array($this, 'block_titrePage'),
            'contenu' => array($this, 'block_contenu'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e71de4fb195ad76fe8c6a4620bb3fed2b634b7cb93107ca5ef86a0a668be4ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e71de4fb195ad76fe8c6a4620bb3fed2b634b7cb93107ca5ef86a0a668be4ef->enter($__internal_9e71de4fb195ad76fe8c6a4620bb3fed2b634b7cb93107ca5ef86a0a668be4ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "mehGsbBundle::base_accueil.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>GsbFrais - ";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 10
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "c2ac694_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_c2ac694_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/c2ac694_bootstrap.min_1.css");
            // line 11
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\">
    ";
        } else {
            // asset "c2ac694"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_c2ac694") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/c2ac694.css");
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\">
    ";
        }
        unset($context["asset_url"]);
        // line 13
        echo "
    ";
        // line 14
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "9997dc8_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9997dc8_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/9997dc8_dashboard_1.css");
            // line 15
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\">
    ";
        } else {
            // asset "9997dc8"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9997dc8") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/9997dc8.css");
            echo "    <link href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" rel=\"stylesheet\">
    ";
        }
        unset($context["asset_url"]);
        // line 17
        echo "    
    ";
        // line 18
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "3ec6e29_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_3ec6e29_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/3ec6e29_style_1.js");
            // line 19
            echo "    <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        } else {
            // asset "3ec6e29"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_3ec6e29") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/3ec6e29.js");
            echo "    <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        }
        unset($context["asset_url"]);
        // line 21
        echo "    
  </head>

  <body>

    <nav class=\"navbar navbar-inverse navbar-fixed-top\">
      <div class=\"container-fluid\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" >GSB | ";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "nom"), "method"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "prenom"), "method"), "html", null, true);
        echo "</a>
        </div>
          
        <div id=\"navbar\" class=\"navbar-collapse collapse\">       
          <ul class=\"nav navbar-nav navbar-right\">
            <li><a href=\"";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pageChangerMdp");
        echo "\">Changer mdp</a></li>
            <li><a>|</a></li>
            <li><a href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("DeconnexionRetourPageAuthentification");
        echo "\">Se déconnecter</a></li>
          </ul>      
        </div>
     
      </div>
    </nav>

    <div class=\"container-fluid\">
      <div class=\"row\">
        <div class=\"col-sm-3 col-md-2 sidebar\">
          <ul class=\"nav nav-sidebar\">
              <li class=\"";
        // line 53
        $this->displayBlock('accueil', $context, $blocks);
        echo "\"><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pageAccueil");
        echo "\">Accueil</a></li>
              <li><hr></li>
          ";
        // line 55
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "menuVisiteur"), "method") == "activer")) {
            // line 56
            echo "              <li><h4>Mes frais</h4></li>
              <li class=\"";
            // line 57
            $this->displayBlock('saisie_fiche_de_frais', $context, $blocks);
            echo "\"><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pageSaisirFicheFrais");
            echo "\">Saisir fiche de frais </a></li>
              <li class=\"";
            // line 58
            $this->displayBlock('consulter_fiche_de_frais', $context, $blocks);
            echo "\"><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pageConsulterFicheFrais");
            echo "\">Consulter fiche de frais</a></li>
          </ul>
          ";
        }
        // line 61
        echo "          ";
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "menuComptable"), "method") == "activer")) {
            // line 62
            echo "              <li><h4>Fiches de frais</h4></li>
              <li class=\"";
            // line 63
            $this->displayBlock('validation_des_frais', $context, $blocks);
            echo "\"><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("pageValiderFrais");
            echo "\">Validation des frais</a></li>
          </ul>
          ";
        }
        // line 66
        echo "        </div>
        <div class=\"col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main\">
          <h1 class=\"page-header\">";
        // line 68
        $this->displayBlock('titrePage', $context, $blocks);
        echo "</h1>
  
            ";
        // line 70
        $this->displayBlock('contenu', $context, $blocks);
        // line 71
        echo "
        </div>
      </div>
    </div>
  </body>
</html>
";
        
        $__internal_9e71de4fb195ad76fe8c6a4620bb3fed2b634b7cb93107ca5ef86a0a668be4ef->leave($__internal_9e71de4fb195ad76fe8c6a4620bb3fed2b634b7cb93107ca5ef86a0a668be4ef_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_516995d41ef55af013111599d726493155616ebb8d2c98a7bc4b631502f3f9e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_516995d41ef55af013111599d726493155616ebb8d2c98a7bc4b631502f3f9e5->enter($__internal_516995d41ef55af013111599d726493155616ebb8d2c98a7bc4b631502f3f9e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_516995d41ef55af013111599d726493155616ebb8d2c98a7bc4b631502f3f9e5->leave($__internal_516995d41ef55af013111599d726493155616ebb8d2c98a7bc4b631502f3f9e5_prof);

    }

    // line 53
    public function block_accueil($context, array $blocks = array())
    {
        $__internal_ab0930c68b6b0bbec65b46c6dcfafdcb6113916ece9cf2c3bb883617c6ec9481 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab0930c68b6b0bbec65b46c6dcfafdcb6113916ece9cf2c3bb883617c6ec9481->enter($__internal_ab0930c68b6b0bbec65b46c6dcfafdcb6113916ece9cf2c3bb883617c6ec9481_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "accueil"));

        
        $__internal_ab0930c68b6b0bbec65b46c6dcfafdcb6113916ece9cf2c3bb883617c6ec9481->leave($__internal_ab0930c68b6b0bbec65b46c6dcfafdcb6113916ece9cf2c3bb883617c6ec9481_prof);

    }

    // line 57
    public function block_saisie_fiche_de_frais($context, array $blocks = array())
    {
        $__internal_f136288e26b4c92baaacbf4e6069cd59bb233364a543785e9b6bbc4afdd3a636 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f136288e26b4c92baaacbf4e6069cd59bb233364a543785e9b6bbc4afdd3a636->enter($__internal_f136288e26b4c92baaacbf4e6069cd59bb233364a543785e9b6bbc4afdd3a636_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "saisie_fiche_de_frais"));

        
        $__internal_f136288e26b4c92baaacbf4e6069cd59bb233364a543785e9b6bbc4afdd3a636->leave($__internal_f136288e26b4c92baaacbf4e6069cd59bb233364a543785e9b6bbc4afdd3a636_prof);

    }

    // line 58
    public function block_consulter_fiche_de_frais($context, array $blocks = array())
    {
        $__internal_ff811c98f6510b61679d8212c1e1c34d9960459d7a75fdb5a0d676472959212c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff811c98f6510b61679d8212c1e1c34d9960459d7a75fdb5a0d676472959212c->enter($__internal_ff811c98f6510b61679d8212c1e1c34d9960459d7a75fdb5a0d676472959212c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "consulter_fiche_de_frais"));

        
        $__internal_ff811c98f6510b61679d8212c1e1c34d9960459d7a75fdb5a0d676472959212c->leave($__internal_ff811c98f6510b61679d8212c1e1c34d9960459d7a75fdb5a0d676472959212c_prof);

    }

    // line 63
    public function block_validation_des_frais($context, array $blocks = array())
    {
        $__internal_1b23749b12a13416524cb4c7db302918584b3fdf50b2eada412742a8e65ad1c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b23749b12a13416524cb4c7db302918584b3fdf50b2eada412742a8e65ad1c0->enter($__internal_1b23749b12a13416524cb4c7db302918584b3fdf50b2eada412742a8e65ad1c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "validation_des_frais"));

        
        $__internal_1b23749b12a13416524cb4c7db302918584b3fdf50b2eada412742a8e65ad1c0->leave($__internal_1b23749b12a13416524cb4c7db302918584b3fdf50b2eada412742a8e65ad1c0_prof);

    }

    // line 68
    public function block_titrePage($context, array $blocks = array())
    {
        $__internal_8045c1a09116fc2cfb4a12d835fc75b1eb8cf844b468eaa5a0732c447ae27f7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8045c1a09116fc2cfb4a12d835fc75b1eb8cf844b468eaa5a0732c447ae27f7b->enter($__internal_8045c1a09116fc2cfb4a12d835fc75b1eb8cf844b468eaa5a0732c447ae27f7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titrePage"));

        
        $__internal_8045c1a09116fc2cfb4a12d835fc75b1eb8cf844b468eaa5a0732c447ae27f7b->leave($__internal_8045c1a09116fc2cfb4a12d835fc75b1eb8cf844b468eaa5a0732c447ae27f7b_prof);

    }

    // line 70
    public function block_contenu($context, array $blocks = array())
    {
        $__internal_871757bed1bb9cc7fd2dab0c133e3ceda5ee9cc8cc3380245e338a4832a98c09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_871757bed1bb9cc7fd2dab0c133e3ceda5ee9cc8cc3380245e338a4832a98c09->enter($__internal_871757bed1bb9cc7fd2dab0c133e3ceda5ee9cc8cc3380245e338a4832a98c09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contenu"));

        
        $__internal_871757bed1bb9cc7fd2dab0c133e3ceda5ee9cc8cc3380245e338a4832a98c09->leave($__internal_871757bed1bb9cc7fd2dab0c133e3ceda5ee9cc8cc3380245e338a4832a98c09_prof);

    }

    public function getTemplateName()
    {
        return "mehGsbBundle::base_accueil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  278 => 70,  267 => 68,  256 => 63,  245 => 58,  234 => 57,  223 => 53,  212 => 8,  199 => 71,  197 => 70,  192 => 68,  188 => 66,  180 => 63,  177 => 62,  174 => 61,  166 => 58,  160 => 57,  157 => 56,  155 => 55,  148 => 53,  134 => 42,  129 => 40,  119 => 35,  103 => 21,  89 => 19,  85 => 18,  82 => 17,  68 => 15,  64 => 14,  61 => 13,  47 => 11,  43 => 10,  38 => 8,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>GsbFrais - {% block title %}{% endblock %}</title>

    {% stylesheets '@mehGsbBundle/Resources/public/bootstrap/css/bootstrap.min.css' %}
    <link href=\"{{ asset_url }}\" rel=\"stylesheet\">
    {% endstylesheets %}

    {% stylesheets '@mehGsbBundle/Resources/public/css/dashboard.css' %}
    <link href=\"{{ asset_url }}\" rel=\"stylesheet\">
    {% endstylesheets %}
    
    {% javascripts '@mehGsbBundle/Resources/public/js/style.js' %}
    <script type=\"text/javascript\" src=\"{{ asset_url }}\"></script>
    {% endjavascripts %}
    
  </head>

  <body>

    <nav class=\"navbar navbar-inverse navbar-fixed-top\">
      <div class=\"container-fluid\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" >GSB | {{app.session.get('nom')}} {{app.session.get('prenom')}}</a>
        </div>
          
        <div id=\"navbar\" class=\"navbar-collapse collapse\">       
          <ul class=\"nav navbar-nav navbar-right\">
            <li><a href=\"{{path('pageChangerMdp')}}\">Changer mdp</a></li>
            <li><a>|</a></li>
            <li><a href=\"{{ path('DeconnexionRetourPageAuthentification') }}\">Se déconnecter</a></li>
          </ul>      
        </div>
     
      </div>
    </nav>

    <div class=\"container-fluid\">
      <div class=\"row\">
        <div class=\"col-sm-3 col-md-2 sidebar\">
          <ul class=\"nav nav-sidebar\">
              <li class=\"{% block accueil %}{% endblock %}\"><a href=\"{{ path('pageAccueil')}}\">Accueil</a></li>
              <li><hr></li>
          {% if app.session.get('menuVisiteur') == \"activer\" %}
              <li><h4>Mes frais</h4></li>
              <li class=\"{% block saisie_fiche_de_frais %}{% endblock %}\"><a href=\"{{ path('pageSaisirFicheFrais') }}\">Saisir fiche de frais </a></li>
              <li class=\"{% block consulter_fiche_de_frais %}{% endblock %}\"><a href=\"{{ path('pageConsulterFicheFrais')}}\">Consulter fiche de frais</a></li>
          </ul>
          {% endif %}
          {% if app.session.get('menuComptable') == \"activer\" %}
              <li><h4>Fiches de frais</h4></li>
              <li class=\"{% block validation_des_frais %}{% endblock %}\"><a href=\"{{path('pageValiderFrais')}}\">Validation des frais</a></li>
          </ul>
          {% endif %}
        </div>
        <div class=\"col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main\">
          <h1 class=\"page-header\">{% block titrePage %}{% endblock %}</h1>
  
            {% block contenu %}{% endblock %}

        </div>
      </div>
    </div>
  </body>
</html>
", "mehGsbBundle::base_accueil.html.twig", "/var/www/gsb/src/meh/GsbBundle/Resources/views/base_accueil.html.twig");
    }
}
