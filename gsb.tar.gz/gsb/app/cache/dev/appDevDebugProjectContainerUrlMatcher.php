<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/css')) {
            if (0 === strpos($pathinfo, '/css/c2ac694')) {
                // _assetic_c2ac694
                if ($pathinfo === '/css/c2ac694.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'c2ac694',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_c2ac694',);
                }

                // _assetic_c2ac694_0
                if ($pathinfo === '/css/c2ac694_bootstrap.min_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'c2ac694',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_c2ac694_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/d7db011')) {
                // _assetic_d7db011
                if ($pathinfo === '/css/d7db011.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd7db011',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_d7db011',);
                }

                // _assetic_d7db011_0
                if ($pathinfo === '/css/d7db011_signin_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => 'd7db011',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_d7db011_0',);
                }

            }

            if (0 === strpos($pathinfo, '/css/9997dc8')) {
                // _assetic_9997dc8
                if ($pathinfo === '/css/9997dc8.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '9997dc8',  'pos' => NULL,  '_format' => 'css',  '_route' => '_assetic_9997dc8',);
                }

                // _assetic_9997dc8_0
                if ($pathinfo === '/css/9997dc8_dashboard_1.css') {
                    return array (  '_controller' => 'assetic.controller:render',  'name' => '9997dc8',  'pos' => 0,  '_format' => 'css',  '_route' => '_assetic_9997dc8_0',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/js/3ec6e29')) {
            // _assetic_3ec6e29
            if ($pathinfo === '/js/3ec6e29.js') {
                return array (  '_controller' => 'assetic.controller:render',  'name' => '3ec6e29',  'pos' => NULL,  '_format' => 'js',  '_route' => '_assetic_3ec6e29',);
            }

            // _assetic_3ec6e29_0
            if ($pathinfo === '/js/3ec6e29_style_1.js') {
                return array (  '_controller' => 'assetic.controller:render',  'name' => '3ec6e29',  'pos' => 0,  '_format' => 'js',  '_route' => '_assetic_3ec6e29_0',);
            }

        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/A')) {
            // pageAuthentification
            if ($pathinfo === '/Authentification') {
                return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Commun\\AuthentificationController::authentificationAction',  '_route' => 'pageAuthentification',);
            }

            // pageAccueil
            if ($pathinfo === '/Accueil') {
                return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Commun\\AccueilController::accueilAction',  '_route' => 'pageAccueil',);
            }

        }

        // DeconnexionRetourPageAuthentification
        if ($pathinfo === '/Deconnexion') {
            return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Commun\\AccueilController::deconnexionAction',  '_route' => 'DeconnexionRetourPageAuthentification',);
        }

        // pageChangerMdp
        if ($pathinfo === '/Changer_mdp') {
            return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Commun\\AccueilController::pageChangerMdpAction',  '_route' => 'pageChangerMdp',);
        }

        // pageSaisirFicheFrais
        if ($pathinfo === '/Saisir_fiche_frais') {
            return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Visiteur\\SaisirFicheFraisController::pageSaisirFicheFraisAction',  '_route' => 'pageSaisirFicheFrais',);
        }

        // pageConsulterFicheFrais
        if ($pathinfo === '/Consulter_fiche_frais') {
            return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Visiteur\\ConsulterFicheFraisController::pageConsulterFicheFraisAction',  '_route' => 'pageConsulterFicheFrais',);
        }

        // delete_hors_forfait_visiteur
        if (0 === strpos($pathinfo, '/supprimerUnHorsForfait') && preg_match('#^/supprimerUnHorsForfait/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_hors_forfait_visiteur')), array (  '_controller' => 'meh\\GsbBundle\\Controller\\Visiteur\\SaisirFicheFraisController::deleteHorsForfaitAction',));
        }

        if (0 === strpos($pathinfo, '/Valider_frais')) {
            // pageValiderFrais
            if ($pathinfo === '/Valider_frais') {
                return array (  '_controller' => 'meh\\GsbBundle\\Controller\\Comptable\\ValiderFraisController::pageValiderFraisAction',  '_route' => 'pageValiderFrais',);
            }

            // pageValiderFraisDunVisiteur
            if (0 === strpos($pathinfo, '/Valider_frais_visiteur') && preg_match('#^/Valider_frais_visiteur/(?P<idFiche>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'pageValiderFraisDunVisiteur')), array (  '_controller' => 'meh\\GsbBundle\\Controller\\Comptable\\ValiderFraisController::pageValiderFraisDunVisiteurAction',));
            }

        }

        if (0 === strpos($pathinfo, '/update_')) {
            // updateEtatHorsForfait
            if (0 === strpos($pathinfo, '/update_etat_hors_forfait') && preg_match('#^/update_etat_hors_forfait/(?P<idFiche>[^/]++)/(?P<idEtat>[^/]++)/(?P<idHorsForfait>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'updateEtatHorsForfait')), array (  '_controller' => 'meh\\GsbBundle\\Controller\\Comptable\\ValiderFraisController::modifierEtatHorsForfaitAction',));
            }

            // updateLibelleHorsForfait
            if (0 === strpos($pathinfo, '/update_libelle_hors_forfait') && preg_match('#^/update_libelle_hors_forfait/(?P<idFiche>[^/]++)/(?P<idHorsForfait>[^/]++)/(?P<btn>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'updateLibelleHorsForfait')), array (  '_controller' => 'meh\\GsbBundle\\Controller\\Comptable\\ValiderFraisController::modifierLibelleHorsForfaitAction',));
            }

        }

        // validerFicheFrais
        if (0 === strpos($pathinfo, '/valider_fiche_frais') && preg_match('#^/valider_fiche_frais/(?P<idFiche>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'validerFicheFrais')), array (  '_controller' => 'meh\\GsbBundle\\Controller\\Comptable\\ValiderFraisController::validerFicheAction',));
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
